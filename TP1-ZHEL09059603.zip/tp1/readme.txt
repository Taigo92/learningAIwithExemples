Lijun Zheng (ZHEL09059603)
Augustin Leo (LEOA25089709)

we have finished questions 3.1-3.4.


